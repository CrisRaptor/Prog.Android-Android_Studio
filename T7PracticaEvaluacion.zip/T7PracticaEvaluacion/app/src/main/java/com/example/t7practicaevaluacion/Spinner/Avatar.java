package com.example.t7practicaevaluacion.Spinner;

public class Avatar {
    private Integer avatar;

    public Avatar(Integer avatar) {
        this.avatar = avatar;
    }

    public Integer getAvatar() {
        return avatar;
    }

    public void setAvatar(Integer avatar) {
        this.avatar = avatar;
    }
}
